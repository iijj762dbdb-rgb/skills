# dahatake/skills

コーディングエージェント向けの **スキル集** を提供するプラグインです。
GitHub Copilot CLI、Claude Code、Gemini CLI、および [APM](https://github.com/microsoft/apm) 対応の各種ハーネスから同じスキルを利用できます。

> **注意**: 各スキルは SKILL.md の配布のみで完結しないものがあります。例えば `markdown-query` は別途 `mdq` CLI のインストールが必要です（[`setup/` スクリプト](#setup-スクリプトでのスキル別追加導入) 参照）。プラグインを入れただけでは動作しない点にご注意ください。

## 提供スキル

| スキル | 概要 |
| --- | --- |
| [`markdown-query`](skills/markdown-query/SKILL.md) | ローカル完結で Markdown 群を横断検索し、ヒットしたチャンクのみを返して Context Window を節約します（BM25 / grep / タグ検索対応）。 |

---

## `markdown-query` スキル詳細

> 「初めてこのリポジトリを触る人」向けに、**何が用意されているのか / 何ができるのか / どういう場合に使うのか** を最初にまとめます。手順だけ知りたい方は [使用方法（`markdown-query`）](#使用方法markdown-query) まで読み飛ばして構いません。

### 何ができるのか（What）

`markdown-query` は、リポジトリ内の Markdown 群（仕様書、設計書、ナレッジ、README など）を **ローカル完結で横断検索** し、ヒットした **見出し単位の小さなチャンク（snippet）だけ** をエージェントに返すスキルです。

- **BM25 検索**: 自然言語クエリで関連度順に上位 N 件を返す。
- **grep 検索**: 完全一致 / 厳密一致したいキーワードに使う。
- **タグ / パス絞り込み**: frontmatter の `tags` や `docs/**` のような glob で範囲限定。
- **見出し階層の俯瞰**: `mdq list` でファイル横断の見出し一覧を取得。
- **本文取得**: `mdq get --chunk-id <ID>` で必要な箇所だけ完全な本文を取り出せる。

### なぜ使うのか（Why）

LLM ベースのコーディングエージェントでは、関連 Markdown を **丸ごと Context に投入すると Context Window を大量消費** し、コスト・速度・回答品質（noise）すべてに悪影響が出ます。

- 「全文を `read_file` させる」 → 数万トークン消費、関係ない章まで読まれる。
- `markdown-query` 経由 → 該当チャンク数百〜千トークン程度に圧縮されて投入される。

実測結果は [評価方法（ベンチマーク）](#評価方法ベンチマーク) を参照してください。

### どういう場合に使うのか（When）

- 複数の Markdown（仕様書群、ナレッジベース、複数 README）を **横断的に参照したい** とき。
- エージェントに「このリポジトリの仕様に従って実装して」と依頼する前に、**関連箇所だけを切り出して渡したい** とき。
- Context Window を節約しつつ、**引用元 (`path:lines`) を明示** したいとき。

逆に **使わないケース**:

- Markdown を編集・生成したい（このスキルは読み取り専用）。
- クラウド埋め込み / リモートベクトル検索を使いたい（本スキルは外部 API を呼びません）。
- 単一の小さな README を眺めたいだけ（普通に開いた方が速い）。

### アーキテクチャ概要

`markdown-query` の実体は本リポジトリ同梱の `mdq/` Python パッケージです。**ローカル完結**（外部 API を呼び出さず、`.mdq/` 配下に SQLite で永続化）であり、CLI・エージェント (Copilot / Claude / Gemini) のいずれからも `python -m mdq` サブプロセスとして起動されます。

```mermaid
flowchart LR
  A["エージェント / ユーザー CLI"] -->|"python -m mdq ..."| B["mdq/cli.py (サブコマンド振り分け)"]
  B --> C["indexer.py + strategies*.py<br/>(Chunking)"]
  B --> D["query_router.py + search.py<br/>(BM25 検索 + snippet 生成)"]
  B --> E["watcher.py (任意, 増分監視)"]
  C --> F[(".mdq/index-&lt;lang&gt;-&lt;strategy&gt;.sqlite")]
  D --> F
  E --> C
  B -. "append" .-> G[(".mdq/usage.jsonl")]
```

主な構成要素:

| 層 | モジュール | 役割 |
|---|---|---|
| CLI | `mdq/__main__.py`, `mdq/cli.py` | argparse でサブコマンド (`index` / `search` / `get` / `list` / `stats` / `watch`) を振り分け、利用ログを記録 |
| Indexing | `indexer.py`, `strategies.py`, `strategies_semantic.py`, `strategies_pageindex.py` | Markdown を Chunking Strategy ごとに分割し、SQLite に upsert |
| Search | `query_router.py`, `search.py` | クエリを 7 ルールで分類して strategy 選定 → BM25 検索 → snippet 生成 |
| Watcher | `watcher.py`（任意、`watchdog` が必要） | ファイル変更を daemon thread で監視し増分索引 |
| Storage | `store.py` + `.mdq/index-<lang>-<strategy>.sqlite` | SCHEMA v6。`(lang, strategy)` の組み合わせごとに独立した DB ファイル |
| Logging | `usage_log.py` + `.mdq/usage.jsonl` | 全 CLI 呼び出しを append-only JSONL に記録（任意の統計レポート生成に使用） |

設計上の前提:

- **物理ファイル分離**: 索引 DB は `(lang, strategy)` の組み合わせごとに別ファイル。検索時に Strategy だけを切り替えれば適切な DB が選択されます。
- **任意拡張**: `watchdog`（Watcher）、`rank_bm25`（高速 BM25）、`fastembed + nltk + numpy`（`semantic_paragraph` 戦略）はいずれも任意依存。未導入時はフォールバック動作します。

### スキルパッケージに含まれるもの

| パス | 内容 |
| --- | --- |
| [`skills/markdown-query/SKILL.md`](skills/markdown-query/SKILL.md) | スキル本体。エージェントが読み込むトリガー定義と手順サマリ。 |
| [`skills/markdown-query/references/cli-reference.md`](skills/markdown-query/references/cli-reference.md) | `mdq` CLI の全サブコマンド・全オプション仕様。 |
| [`skills/markdown-query/references/query-patterns.md`](skills/markdown-query/references/query-patterns.md) | よくあるクエリ例（タグ絞り込み、grep、見出し俯瞰など）。 |
| [`skills/markdown-query/references/indexing-internals.md`](skills/markdown-query/references/indexing-internals.md) | 索引のデータモデルとチャンク分割ルール（高度な利用者向け）。 |
| [`skills/markdown-query/examples/prompt-snippets.md`](skills/markdown-query/examples/prompt-snippets.md) | Copilot Chat / Custom Agent に組み込む際のプロンプト例。 |
| [`mdq/`](mdq/) | スキルが内部で呼び出す Python 製 CLI 本体。 |
| [`setup/setup-markdown-query.{ps1,sh}`](setup/) | `mdq` を `.venv` にインストールするセットアップスクリプト。 |
| [`tools/markdown-query/`](tools/markdown-query/) | Context 削減効果を数値で確認するためのベンチマーク CLI。 |

## インストール

### 前提条件

- Git CLI（全インストール経路で必須）
- Node.js 18+ （`npx skills` 経由でインストールする場合のみ必須）
- Python 3.11+（`markdown-query` の `mdq` CLI を利用する場合のみ必須）

各エージェント CLI（`copilot` / `claude` / `gemini` / `apm`）は事前にインストールしておいてください。

### APM（複数ハーネス対応）

[APM](https://github.com/microsoft/apm) を使うと、1 コマンドで複数のエージェント環境に導入できます。

```bash
apm install dahatake/skills
```

### GitHub Copilot CLI

`copilot` CLI のインタラクティブセッション内で次を実行します（初回のみマーケットプレイス追加）。

```text
/plugin marketplace add dahatake/skills
/plugin install dahatake-skills@dahatake-skills
```

シェルから直接実行する場合:

```bash
copilot plugin marketplace add dahatake/skills
copilot plugin install dahatake-skills@dahatake-skills
```

更新する場合:

```bash
copilot plugin update dahatake-skills
```

インストール確認:

```bash
copilot plugin list
```

### Claude Code

`claude` を起動した対話プロンプト内で次を実行します（初回のみマーケットプレイス追加）。

```text
/plugin marketplace add dahatake/skills
/plugin install dahatake-skills@dahatake-skills
```

インストール状況は `/plugin list` で確認できます。

### Gemini CLI

```bash
gemini extensions install https://github.com/dahatake/skills
```

更新する場合:

```bash
gemini extensions update dahatake-skills
```

> **Gemini CLI 連携は未検証です**。`gemini-extension.json` は最小構成（name / version / description）のみで提供しており、Gemini CLI 側で `skills/` 配下が自動認識されるかは環境により異なる可能性があります。動作確認できない場合は手動インストールまたは `setup/` スクリプトをご利用ください。

> **Codex CLI について**: 本レビュー時点（2026 年 5 月）の [openai/codex](https://github.com/openai/codex) には公式のプラグインマーケットプレイス機能はありません。Codex CLI から本リポジトリのスキルを使う場合は、下記「手動インストール」または `setup/` スクリプトをご利用ください。

### 手動インストール（GitHub Copilot 全般）

```bash
npx skills add https://github.com/dahatake/skills/tree/main/skills -a github-copilot -g -y
```

### `setup/` スクリプトでのスキル別追加導入

スキルによっては、CLI 等の追加コンポーネントが必要です。`setup/` 配下のスクリプトでローカル `.venv` に必要な CLI をインストールできます。

#### `markdown-query` スキル: `mdq` CLI

リポジトリをクローンしたうえで、OS に応じて次のいずれかを実行してください。

**Windows (PowerShell)**

```powershell
git clone https://github.com/dahatake/skills.git
cd skills
./setup/setup-markdown-query.ps1
```

主なオプション:

| オプション | 説明 |
| --- | --- |
| `-CheckOnly` | 変更を加えず、現状のみを確認する |
| `-ForceRecreateVenv` | `.venv` の Python が 3.11 未満なら作り直す |
| `-WithWatch` | `mdq watch` 用に `watchdog` も導入する |
| `-From <PATH>` | PyPI ではなくローカルソースから `pip install -e` する |

**macOS / Linux (bash)**

```bash
git clone https://github.com/dahatake/skills.git
cd skills
chmod +x ./setup/setup-markdown-query.sh
./setup/setup-markdown-query.sh
```

主なオプション:

| オプション | 説明 |
| --- | --- |
| `--check-only` | 変更を加えず、現状のみを確認する |
| `--force-recreate-venv` | `.venv` の Python が 3.11 未満なら作り直す |
| `--with-watch` | `mdq watch` 用に `watchdog` も導入する |
| `--from PATH` | PyPI ではなくローカルソースから `pip install -e` する |
| `-h`, `--help` | ヘルプを表示する |

> 前提: Python 3.11 以上。スクリプトはリポジトリルートに `.venv` を作成し、その中に `mdq` をインストールします。インストール後はシェルで `.venv` を有効化するか、`./.venv/bin/python -m mdq ...`（Windows は `./.venv/Scripts/python.exe -m mdq ...`）の形で呼び出してください（スクリプト末尾の "Next steps" と同じ形式）。

## 使用方法（`markdown-query`）

`markdown-query` は `mdq` CLI を内部で呼び出します。エージェントに依頼する場合も、手動で実行する場合も、**事前にインデックスを作成しておく必要があります**。

### 1. インデックスの作成（初回 / 必須）

`.mdq/index.sqlite` はセッション間で共有されない前提のため、**このスキルを使う前に必ず 1 回実行してください**。検索対象のリポジトリのルートで実行します。

```bash
mdq index
```

- 既定でカレントディレクトリを再帰走査し、`.md` / `.markdown` を索引化します。
- 既定除外: `.git`, `node_modules`, `.venv`, `venv`, `__pycache__`, `.mdq`, `dist`, `build`, `.next`, `.cache`
- `.gitignore` は既定で尊重されます。
- `.mdq/` 自体を `.gitignore` に追加することを推奨します。

### 2. インデックスの更新

ファイルを追加・編集した後はインデックスの更新が必要です。

```bash
# 増分更新（SHA-1 + mtime が一致するファイルはスキップ）
mdq index

# 削除されたファイルのチャンクも自動で prune されます（--no-prune で無効化可）
```

ファイル変更を逐次反映したい場合は、別ターミナルで watch モードを起動できます（`watchdog` が必要、`setup-markdown-query` で `-WithWatch` / `--with-watch` を指定するとインストールされます）。

```bash
mdq watch
```

### 3. 検索

```bash
mdq search --q "クエリ" --top-k 5 --max-tokens 800
```

主なオプション:

| オプション | 説明 |
| --- | --- |
| `--q` | 検索クエリ（必須） |
| `--top-k` | 返すヒット数（既定 5 推奨範囲 3〜5） |
| `--max-tokens` | 出力の最大トークン数（既定 800 推奨範囲 400〜800） |
| `--paths` | 検索対象パスを絞り込み（例: `"docs/**"`） |
| `--tags` | frontmatter のタグで絞り込み |
| `--mode` | `bm25`（既定） / `grep` |
| `--snippet-radius` | ヒット行前後の表示行数（既定 ±2） |

出力は JSONL（1 行 = 1 ヒット）です。

### 4. 本文取得（必要時のみ）

検索結果の `chunk_id` を指定して該当チャンクの本文を取得します。

```bash
mdq get --chunk-id <ID>
```

### エージェントから使う場合

インデックス作成後、エージェントに次のように依頼できます。

> このリポジトリ配下の Markdown から "context window" を含む見出しを探して。

`markdown-query` スキルが起動し、ヒットしたチャンクのみが返ってくれば成功です。

> `mdq` の代わりに `python -m mdq` でも同じサブコマンドを実行できます。詳細なオプションは [`skills/markdown-query/references/cli-reference.md`](skills/markdown-query/references/cli-reference.md) を参照してください。

## Chunking Strategy と言語選択

`mdq index` / `mdq search` には **言語** (`--lang`) と **Chunking Strategy** (`--strategy`) を指定できます。索引 DB は組み合わせごとに別ファイル (`.mdq/index-<lang>-<strategy>.sqlite`) として作成されるため、複数 Strategy を並行運用できます。

### 言語 (`--lang`)

| 値 | FTS5 tokenizer | 用途 |
|---|---|---|
| `ja-jp`（既定） | `trigram`（SQLite 3.34+。未対応環境では `unicode61` にフォールバック） | 日本語 |
| `en-us` | `unicode61` | 英語 |

### Chunking Strategy (`--strategy`)

| 戦略 | 境界 | 既定パラメータ | overlap | 任意依存 |
|---|---|---|---|---|
| `heading`（既定 / legacy） | Markdown 見出しごとに 1 chunk | `--max-chunk-chars`（既定 0 = 無制限） | なし | なし |
| `heading_recursive` | 見出し chunk が大きい場合に段落／行で再分割 | 2,000 字超で再分割 | 段落単位（既定 1 段落、`--overlap-paragraphs` で 0〜5） | なし |
| `fixed_window` | 見出し構造を無視し、固定窓スライド | 1,000 字 / overlap 200 字 | 200 字 | なし |
| `semantic_paragraph` | 見出しを hard boundary とし、文 embedding 類似度（Kamradt 二分探索）で意味境界決定 | min 200 / max 1,000 字、percentile 50〜99 | なし（意味境界自動） | `pip install -e .[semantic]`（fastembed + nltk + numpy）。既定モデル `intfloat/multilingual-e5-large`（初回 ~2GB DL） |
| `pageindex` | 見出しベースのツリー索引。各ノードに `chunks.summary`（先頭抽出）を保存 | サマリ 200 字 / モード `head` | なし | なし（LLM 不要） |
| `auto`（`search` 既定） | クエリ内容から自動選択（次節「クエリルーティング」参照） | — | — | — |

主要オプション（`mdq index` / `mdq search` 共通）:

| オプション | 説明 |
|---|---|
| `--lang ja-jp|en-us` | 言語選択 |
| `--strategy <name>` | Chunking Strategy（`search` では `auto` 既定） |
| `--max-chunk-chars N` | `heading` / `semantic_paragraph` のチャンク最大文字数 |
| `--overlap-paragraphs N` | `heading_recursive` の段落単位 overlap |
| `--late-chunking` | `semantic_paragraph` 索引時に `chunk_embedding` (float32 BLOB) を保存 |
| `--fusion-alpha α` | `search` で BM25 + embedding 類似度を線形加重統合（`--late-chunking` 索引が前提） |
| `--include-parent` / `--with-parent-depth N` | ヒットチャンクの直近上位見出しチェーンを `expansion.parent` に含める |
| `--pageindex-tree-depth N` | `pageindex` で `search` 時にルート→ヒットの summary 連鎖を `expansion.tree_path` に返す |
| `--db <PATH>` | `--lang/--strategy` から導出される DB パスを明示上書き |

CLI 例:

```sh
# 日本語・heading_recursive で索引（段落 overlap=2）
python -m mdq index --lang ja-jp --strategy heading_recursive --overlap-paragraphs 2

# semantic_paragraph で索引（late-chunking 有効化）
pip install -e .[semantic]
python -m mdq index --strategy semantic_paragraph --max-chunk-chars 1000 --late-chunking

# 英語・auto 選択で検索
python -m mdq search --lang en-us --q "design pattern overview" --with-parent-depth 2
```

## クエリルーティング（`--strategy auto`）

`mdq search --strategy auto`（既定）は、`mdq/query_router.py` がクエリを以下 7 ルールで分類し、選定 Strategy の DB が存在しない場合は fallback chain に従って切り替えます。

### ルール（上から評価、最初に該当したもの採用）

| Rule | 条件 | 選択 Strategy | reason ID |
|---|---|---|---|
| R2′ | `--mode grep` | `heading` | `exact_match` |
| R1 | ID 風（英数+ハイフンの単語） | `heading` | `id_lookup` |
| R2 | 引用符付き完全一致 | `heading` | `exact_match` |
| R6 | コード片（バッククォート / 記号密） | `fixed_window` | `code_fragment` |
| R3 | 短い固有名詞（≤ 2 トークン） | `heading` | `short_proper_noun` |
| R4 | 概念語（`概要` / `とは` / `what` 等） | `pageindex`（不在時はフォールバック） | `concept_overview` |
| R5 | 物語的質問（`なぜ` / `どのように` / `?`） | `semantic_paragraph`（不在時 `heading_recursive`） | `narrative_query` |
| R7 | 既定 | `heading_recursive` | `default` |

### Fallback chain

選定 Strategy の DB が `.mdq/index-*-*.sqlite` に存在しなければ、以下の順で利用可能な最初のものへ切り替わります（`fallback_used=True` が usage_log に記録されます）。

`pageindex → semantic_paragraph → heading_recursive → heading → fixed_window`

複数 Strategy を並行運用したい場合は、用途に応じた組み合わせで先に索引を作成しておくことを推奨します。

## 索引データファイルと更新

`.mdq/` 配下に永続化される主要ファイルと更新トリガは以下のとおりです。`.mdq/` は `.gitignore` 推奨です。

| ファイル / テーブル | 役割 | 更新契機 | サイズ目安 |
|---|---|---|---|
| `.mdq/index-<lang>-<strategy>.sqlite` の `files` テーブル | ファイル単位の SHA-1 / mtime / size / frontmatter | `mdq index` / Watcher | 〜数 MB |
| 同 `chunks` テーブル | 分割後のチャンク本文 + heading_path + part_index + parent_chunk_id (v4) | 同上 | 数十〜数百 MB |
| 同 `chunks_fts`（FTS5 mirror） | 全文検索用トークン索引（v3 以降） | `chunks` への INSERT/DELETE と同一トランザクション | `chunks` の 0.5〜1.5 倍 |
| 同 `chunks.text_raw` 列 (v5) | `semantic_paragraph` の contextualize ON 時に原文を保存 | `semantic_paragraph` 索引時のみ | `chunks.body` の 0.7 倍程度 |
| 同 `chunks.chunk_embedding` 列 (v5) | float32 埋め込みベクトル | `semantic_paragraph` + `--late-chunking` 索引時のみ | チャンク数 × 4 KB |
| 同 `chunks.summary` 列 (v6) | `pageindex` のノードサマリ | `pageindex` 索引時のみ | チャンク数 × 最大 2 KB |
| `.mdq/usage.jsonl` | 全 mdq CLI 呼び出しの append-only ログ | 全サブコマンド完了時 | 1 行 ~500 B |

運用 Tips:

- **増分判定**: `mdq index` は `(stored_sha1 == current_sha1)` で skip するため、`git checkout` のように内容が同じで mtime だけ変わるケースでも余計な再索引は走りません。完全性が要件なら `--rebuild` を使用してください。
- **Strategy 切り替え時**: 新 Strategy の索引は別 DB ファイルに生成されるため、既存 DB は触らず並行運用できます。
- **DB 破損時**: `.mdq/index-<lang>-<strategy>.sqlite` を削除して `mdq index --strategy <name>` で再生成すれば復旧します。`.mdq/usage.jsonl` は索引と独立なので削除不要です。
- **同一 (lang, strategy) の並行書き込み禁止**: SQLite ファイルロック (Windows) で失敗します。Watcher 実行中に手動 `mdq index` を流す場合は Watcher を停止してください。
- **機微情報注意**: `.mdq/usage.jsonl` には検索クエリ `args.q` がそのまま記録されます。機密語句で検索した場合は内容を確認の上でリポジトリ外に出してください。

## 評価方法（ベンチマーク）

「本当に Context Window を節約できているか」を **自分のリポジトリで数値確認** するためのベンチマーク CLI を [`tools/markdown-query/benchmark.py`](tools/markdown-query/benchmark.py) として同梱しています。詳細は [`tools/markdown-query/README.md`](tools/markdown-query/README.md) を参照してください。

### 何を測るのか

同一クエリ集合に対し、次の 3 シナリオを比較します。

| シナリオ | Context に投入する内容 | 想定する使い方 |
| --- | --- | --- |
| `baseline_full` | 索引対象配下の **全 Markdown 本文** | スキルを使わない場合の上限値 |
| `mdq_bm25` | `mdq search --mode bm25` のヒットのみ | 既定の検索モード |
| `mdq_grep` | `mdq search --mode grep` のヒットのみ | 厳密一致モード |

各シナリオで **応答トークン数 / 検索 wall-clock / ベースライン比削減率 / coverage（任意）** を計測します。

### 実行手順

1. 索引を作成しておく（未作成なら `--ensure-index` を付ければ自動で作成されます）。

   ```bash
   mdq index
   ```

2. 計測したいクエリを 1 行 1 件で書いたファイルを用意します（例として [`tools/markdown-query/queries.sample.txt`](tools/markdown-query/queries.sample.txt) を同梱）。

3. ベンチマークを実行します。

   ```bash
   python tools/markdown-query/benchmark.py \
     --queries-file tools/markdown-query/queries.sample.txt \
     --top-k 5 --max-tokens 800 --repeat 3 --ensure-index
   ```

4. 結果は `tools/markdown-query/results/bench-<UTCタイムスタンプ>.{json,md}` に出力されます（`results/` は `.gitignore` 済）。

### 結果（Markdown レポート）の見方

`bench-*.md` には次のセクションが順に並びます。

1. **Environment**: トークナイザ（`tiktoken/cl100k_base` か fallback）、Python・OS・コミットハッシュ。**他環境の数値と絶対比較するときは必ずここを確認**。
2. **Parameters**: `--top-k` `--max-tokens` `--repeat` などの実行条件。
3. **Index summary**: `--ensure-index` 時の索引作成の所要時間。
4. **baseline_full**: 全文投入時の `files / chars / tokens`。これが **削減率の分母**。
5. **Skill なし vs Skill あり (プロンプトトークン比較)**: シナリオごとに次を表示します。
   - `avg_response_tokens`: クエリ平均の応答トークン数（小さいほど Context 節約）。
   - `avg_vs_baseline_savings_pct`: ベースライン比の削減率（例: `98.5%` なら全文投入比 1.5% に圧縮）。
   - `latency_ms_all`: 全クエリ × `--repeat` 回の `mean / p50 / p95 / min / max`（同一マシン内の A/B 比較用）。
   - `per_query[]`: クエリごとの hits 数、トークン、削減率、`coverage_proxy`（期待パス付き JSON 利用時のみ）。

### 数値の解釈と注意点

- **削減率が高い = 良い** とは限らない。`coverage_proxy`（期待パスが Hit に含まれた割合）が低ければ、絞り込みすぎている可能性があります。期待パス付きの `--queries-json` でセットで評価するのが推奨。
- **`latency_ms` は絶対値で比較しない**。同一マシン・同一コミット内で `--mode bm25` vs `grep`、`--top-k` 違いなどを A/B するための指標です。
- **このベンチマークは LLM API を呼ばない**。回答品質ではなく「Context 投入量と検索速度の代理指標」のみを測ります。回答品質まで含めた評価は別途必要です。
- **撤去判断の閾値はツール側では提示しません**。「埋め込みベース RAG が導入されたら本スキルを退役させるか」などは、出力された数値を見て利用者が判断してください。

### クエリに期待パスを紐付けて評価する（推奨）

`coverage_proxy` を出すには、期待パス付きの JSON を渡します。

```json
[
  {"q": "業務要件 概要", "expected_paths": ["sample/business-requirement.md"]},
  {"q": "ユースケース", "expected_paths": ["sample/usecase-list.md"]}
]
```

```bash
python tools/markdown-query/benchmark.py \
  --queries-json my-queries.json --repeat 3
```

### 実行例: `sample/` フォルダーに対するベンチマーク結果

本リポジトリ同梱の [`sample/`](sample/) 配下（業務要件・ユースケース・サービス記述書の Markdown 4 ファイル）に対し、[`tools/markdown-query/queries.sample.txt`](tools/markdown-query/queries.sample.txt) の 5 クエリで実行した **参考値** です。生のレポートは [`tools/markdown-query/results/bench-20260514T012257Z.md`](tools/markdown-query/results/bench-20260514T012257Z.md) を参照してください。

> **重要 — あくまで「例」です**: 以下の数値は **特定の環境・特定のリポジトリ・特定のクエリ集合** で測定したものであり、**ユーザーの環境で同じ結果や精度を保証するものではありません**。Markdown の量・章構造・クエリの語彙・トークナイザ・マシン性能などにより結果は大きく変動します。必ず自分のリポジトリで `benchmark.py` を実行して判断してください。

**測定環境（例）**: `tiktoken/cl100k_base` / Python 3.12.10 / Windows 11 / `top_k=5`, `max_tokens=800`, `repeat=3`

**baseline_full**: 4 files / 83,230 chars / **68,440 tokens**

| シナリオ | avg tokens (with skill) | avg savings vs baseline | latency mean / p50 / p95 (ms) |
| --- | ---: | ---: | --- |
| `mdq_bm25` | 1,794.6 | **97.38%** | 13.35 / 13.65 / 14.20 |
| `mdq_grep` | 700.6 | **98.98%** | 1.45 / 0.47 / 3.33 |

クエリ別（`mdq_bm25`、抜粋）:

| query | hits | tokens | savings % |
| --- | ---: | ---: | ---: |
| ロイヤルティプログラム | 5 | 2,484 | 96.37 |
| 生成AI パーソナライズ | 5 | 1,816 | 97.35 |
| ポイント付与 失効 | 5 | 1,250 | 98.17 |
| 会員 同意管理 | 5 | 1,402 | 97.95 |
| ユースケース | 5 | 2,021 | 97.05 |

> この例では全文投入の **約 1〜3%** までプロンプトトークンが圧縮されています。一方で `mdq_grep` は語の表記揺れに弱く、`生成AI パーソナライズ` など 0 hit になるクエリもあります（`savings % = 100` は「ヒットなし」を意味するため、別途 `coverage_proxy` での確認が必要です）。**削減率だけで判断せず、必ず期待パス付き JSON で coverage も併せて評価してください**。

## 利用統計レポート（任意）

`mdq` の全 CLI 呼び出しは `.mdq/usage.jsonl` に append-only で記録されます。これを集計して、Skill が実際に呼ばれているか・Context 削減が効いているかを定量化できます。

- 集計モジュール: [`mdq/usage_stats.py`](mdq/usage_stats.py)
- レポート生成スクリプト: [`tools/markdown-query/generate_usage_report.py`](tools/markdown-query/generate_usage_report.py)
- 出力先: `tools/markdown-query/usage-report/YYYY-MM-DD.{json,md}` および `latest.{json,md}`
- 保持期間: 既定 90 日（`--retention-days N` で変更、`0` で無効化）。`latest.*` は常に保持されます。

`usage.jsonl` の各行は次のスキーマで、検索ごとに 1 行ずつ追記されます:

```json
{
  "ts": "2026-05-21T12:34:56.789Z",
  "command": "search",
  "args": {"q": "…", "mode": "bm25", "strategy": "auto",
            "effective_strategy": "heading_recursive",
            "router_reason": "default", "router_rule_id": 7,
            "router_fallback_used": false},
  "elapsed_ms": 42,
  "result": {"hit_count": 8, "snippet_chars": 1234, "source_file_chars": 56789,
              "score_top": 12.3, "score_2nd": 9.8, "parent_expanded": 2},
  "exit_code": 0,
  "context": {"repo_root": "/abs/path"}
}
```

### 主要指標（抜粋）

レポートは「インデックスの統計情報」と「Skill 利用統計情報」の 2 セクションで構成され、後者は直近 7 日間を既定ウィンドウとして以下のような指標を算出します。

| グループ | 指標 | 何を見るか |
|---|---|---|
| 基盤・索引 | E1 索引サイズ / E2 索引鮮度 / E5 孤児チャンク削除累計 / F2 索引差分更新比率 | 索引が新しいか、増分更新が効いているか |
| 呼び出し量 | A1 サブコマンド別呼び出し回数 / A4 Skill ルーティング記載有無 / D1 DO NOT USE FOR 違反 | Skill が実際に呼ばれているか、棲み分けが守られているか |
| Context 削減 | B1 Context 削減率 / B2 引数平均（top_k / max_tokens / snippet_radius） / B3 get/search 比率 | Skill の中核目的（Context 節約）が効いているか |
| 結果品質 | C1 ヒット 0 件率 / C2 上位 2 件 score 差 / C3 expansion フラグ使用率 | 検索がクエリに合っているか、チャンク粒度が適切か |
| パフォーマンス | F1 search 実行時間 p50/p95 | Skill の応答性能 |
| ルーティング (v2.0) | H1 auto_strategy 分布 / H2 parent 展開率 | `--strategy auto` で何が選ばれているか、parent 展開が効いているか |

> 注: 一部の指標（例: `A2 Step あたり呼び出し回数`、`G1 mdq 利用 Step 完了率差`、`G4 Step 再実行回数差`、`D3 典型クエリ出現率`）は上位オーケストレーター（HVE 等）が `HVE_STEP_ID` / `context.run_id` などを usage_log に注入する前提で動作するため、本プラグイン単体では未利用となります。詳細は [`mdq/usage_stats.py`](mdq/usage_stats.py) のドキュメンテーション参照。

## 他リポジトリへの移植チェックリスト

`markdown-query` Skill を別リポジトリへ持ち込む際に **「エージェントが実際に呼んでくれる状態」** へ仕上げるための導入チェックリストです。配置だけでは採用率が伸びないことが多く、以下 5 項目を併せて整備することを推奨します。

### 1. Windows 文字コード起因の exit 1 を解消する

[`mdq/cli.py`](mdq/cli.py) の `main()` は標準出力を再構成しないため、Windows の cp932 ロケールでヒットに絵文字が含まれると `UnicodeEncodeError` で **exit code 1** を返すことがあります。エージェントは「壊れている」と判断してツールを回避するため、最初に解消してください。

- 恒久対策: `main()` の冒頭で `sys.stdout.reconfigure(encoding='utf-8', errors='replace')` を呼ぶ。
- 暫定回避: 環境変数 `PYTHONIOENCODING=utf-8` を設定する。

### 2. 最上位ルールに Markdown 検索の優先順位を明記する

リポジトリ最上位のエージェント共通ルール文書（`.github/copilot-instructions.md` / `CLAUDE.md` / `AGENTS.md` 等）に、優先順位を明記してください。

```markdown
- Markdown ファイル群を対象とした検索・横断クエリは、まず `markdown-query` Skill
  （`python -m mdq search ...`）を試す。0 ヒットまたは目的が一致しない場合に限り
  `grep_search` / `read_file` へフォールバックする。
- ソースコード（`.py`, `.ts` 等）の検索や、Markdown 編集／生成は本 Skill の対象外。
```

### 3. SKILL.md `description` に `grep_search` も `PREFER OVER` に含める

[`skills/markdown-query/SKILL.md`](skills/markdown-query/SKILL.md) の frontmatter で `read_file` / `cat` だけでなく `grep_search` も明示すると、上位指示で `grep_search` を「標準」とするエージェントホストでも選ばれやすくなります。

### 4. Skill ルーティング表で `.md` 限定優先を明示する

ルーティング相当文書がある場合は `grep_search` 行から `markdown-query` への誘導文言を追加してください。

### 5. 初回索引の自動化（採用障壁の除去）

索引が無い状態で `mdq search` を呼ぶと 0 件返却となり、エージェントが諦める誘因になります。以下のいずれかで初回索引を自動化してください。

- CI / pre-commit / devcontainer 起動スクリプトに `python -m mdq index` を組み込む
- エージェント onboarding ステップで `mdq stats` → 0 件なら自動 `index` を実行（[`skills/markdown-query/SKILL.md`](skills/markdown-query/SKILL.md) §手順サマリに該当記載あり）
- リポジトリルートに `mdq.toml` を作成し `[index].roots` にドキュメントディレクトリを列挙（推奨）。[`mdq/cli.py`](mdq/cli.py) の `DEFAULT_ROOTS` は設定ファイル不在時の最小フォールバックです

### 採用率の検証

導入後 1〜2 週間運用してから [`tools/markdown-query/generate_usage_report.py`](tools/markdown-query/generate_usage_report.py) を実行し、**A1 `search` 件数** がタスク数に対して妥当か確認してください。極端に少ない場合は上記 1〜5 の未実施項目を再点検します。自リポジトリでの実測トークン削減率は `python tools/markdown-query/benchmark.py` で取得し、**Skill 改善前後の 2 回比較で相対変化を見る** ことを推奨します。

## リポジトリ構成

```
README.md                           本ファイル
LICENSE                             MIT ライセンス
plugin.json                         プラグイン定義（Copilot CLI / 共通）
apm.yml                             APM マーケットプレイス定義（authoring）
.claude-plugin/marketplace.json     Claude Code / Copilot CLI 用マーケットプレイス
.claude-plugin/plugin.json          Claude Code 用プラグイン定義
gemini-extension.json               Gemini CLI 拡張定義
.mcp.json                           MCP サーバー設定（現状は空、必要に応じて拡張）
setup/                              スキル別の追加 CLI インストールスクリプト
  setup-markdown-query.ps1
  setup-markdown-query.sh
skills/                             スキル本体
  markdown-query/
    SKILL.md
    examples/
    references/
```

> **注意**: `plugin.json`（ルート）と `.claude-plugin/plugin.json` は内容を重複させています。片方を更新する際はもう片方も同期してください。`apm.yml` と `.claude-plugin/marketplace.json` も同様です。

## ライセンス

[MIT](LICENSE)

